<!DOCTYPE html>
<html>

<head>

    <meta name="viewport" content="width=devices-width,initial-scale=1.0">


    <title>IMD Maintenences</title>
    <!--   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
         
-->
    <link rel="stylesheet" type="text/css" href="netsource/css/normalize.css">

    <link rel="stylesheet" type="text/css" href="netsource/css/all.css">

    <link rel="stylesheet" type="text/css" href="netsource/css/ionicons.min.css">

    <link rel="stylesheet" type="text/css" href="netsource/css/Grid.css">

    <link rel="stylesheet" type="text/css" href="style.css">

    <link rel="stylesheet" type="text/css" href="netsource/css/login.css">

    <link rel="stylesheet" type="text/css" href="queries.css">



    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">

    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800" rel="stylesheet">
    
   
</head>

<body>

    <header>

        <nav>
            <div class="row">
                <img src="netsource/image/IMD_logo.jpg" class="logo">

                <img src="netsource/image/IMD_logo.jpg" class="logo-stick">

                <ul class="main-nav">

                    <li><a href="#About" id="About Us">About Us</a></li>

                    <li><a href="#Maintenanceinfo" id="Maintenance">Maintenance Info</a></li>

                    <li><a href="stationcities.html" id="Cities">Stations</a></li>
                    <li><a href="#contact" id="Contact Us">Contact Us</a></li>
                    <li><a href="https://lex-web-ui-codebuilddeploy-1aelowji3-webappbucket-1xa5ccwjk82vc.s3.amazonaws.com/index.html" id="loginpage">Help</a></li>
                    <li><a href="login.html" id="loginpage">Login</a></li>


                </ul>
            </div>
        </nav>

        <div class="hero-text-box" style="text-align:center;">
            <h1>India Meteorological Department</h1>
            <h1 class="h1headingsmall"> Ministry of Earth Sciences<br>
                Government of India<br><br> AWS/ARG Maintenance</h1>

            <a class="btn btn-full" href="#About">About Us </a>
            <a class="btn btn-ghost" href="#Maintenanceinfo">Maintenance Info </a>
        </div>

        <!--   <div class="bg-model">
            
                <div class="model-content">
                    
                </div>
            
            </div>
            -->

    </header>


    <section class="section-feature js--section-features" , id="About">

        <div class="row">
            <h2>Automatic weather station (AWS)</h2>
            <p class="long-copy" style="text-align:center;">
                The automatic weather station is made for measuring several meteorological parameters. It is designed and built for the long-term use under extreme weather conditions without any infrastructure. The AWS can be equipped with diverse sensors according to the specific customer requirements.


            </p> <br><br>


            <p class="long-copy" style="text-align:center;">
                AWS provides us the facility to automatically transmit the measurement of meteorological elements in form of electrical signals through sensors. These signals are then transformed into actual meteorological data.

            </p>

        </div>

        <br>



        <div class="row">

            <center>
                <div class="col span-1-of-3 box">
                    <i class="ion-thermometer icon-big"></i>
                    <h3>Temperature</h3>
                    <p>
                        The AWS records the various sensors which includes Thermometer, Anemometer, Wind-vane, Hy-grometer, Barometer, Ceilometer, Visibility sensor,Rain gauge, Ultrasonic depth sensor, Pyranometer etc.
                    </p>

                </div>

                <div class="col span-1-of-3 box">
                    <i class="ion-ios-rainy-outline icon-big"></i>
                    <h3>Rainfall</h3>
                    <p>
                        Automatic Rain Gauge System (ARGS) is a weather instrument for measuring rainfall and monitoring rain rate. It helps to provide reliable and low cost solution.
                    </p>
                </div>


                <div class="col span-1-of-3 box">

                    <i class="ion-battery-low icon-big"></i>
                    <h3>Battery Status</h3>

                    <p>All the sensors and equipment of AWS executes by consuming power from various sources like So-larenergy, Batteries, Regulators, Windturbine, Lo-calelectricitygrid. </p>
                </div>

            </center>


        </div>

    </section>



    <section class="section-step" , id="Maintenanceinfo">

        <div class="row">
            <h2>Maintenance Info</h2>
        </div>
        <div class="row">
            <div class="col span-1-of-2 step-box" id="image1">
                <img src="netsource/image/aws_meteorological_station___kws131_product_114.jpg" alt="AWS sensor" class="sensor-screen">
            </div>
            <div class="col span-1-of-2 step-box">
                <div class="M-info">
                    <div>1</div>
                    <p>There are 1300&#43; AWS Stations across the country!</p>
                </div>
                <div class="M-info">
                    <div>2</div>
                    <p>Total Maintenance reported is : <?php
  
$con = mysqli_connect("173.194.107.32","NikhilOke","1234","imd_db");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


$sql = "SELECT * FROM Report  ORDER BY date DESC";
$result = mysqli_query($con, $sql); 
                        $count=0;

                if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
            $count++;
    }
                echo  $count;   
}        
?>

                    </p>
                </div>
                <div class="M-info">
                    <div>3</div>
                    <p>Total visit to website is :   
                        <?php 
	$handle = fopen("counter.txt", "r"); 
	if(!$handle)
	  {
		echo "could not open the file" ; 
	  }
	else
	{
		$counter = ( int ) fread ($handle,20) ;
	    fclose ($handle) ; 
		$counter++ ; 
		echo $counter;
		
		$handle = fopen("counter.txt", "w" ) ; 
		fwrite($handle,$counter) ;
		fclose ($handle) ;
	}
	?> </p>
                </div>

            </div>
        </div>
    </section>

    <section class="section-stepcontact" id="contact">
        <h2>Contact us</h2>
        <div class="row contactmargin">


            <div class="col span-1-of-2 ">

                <i class="far fa-address-card contacticon-big"></i>

            </div>

            <div class="col span-1-of-2 ">

                <p>Office of Director General of Meteorology, India Meteorological Department, Mausam Bhavan, Lodi Road, New Delh - 110003</p>
                <br>
                <p><strong>Phone No. </strong>(TOLL FREE NUMBER) : 1800 220 161 </p>
                <br>
                <p><a href="http://www.imd.gov.in/pages/about_senior_officers.php"> Senior Officers of IMD</a></p>

            </div>


        </div>


    </section>



    <footer>
        <div class="row">
            <div class="col span-1-of-2">
                <ul class="footer-nav">
                    <li><a href="#About">About us</a></li>
                    <li><a href="#contact">Contact Us</a></li>
                    <li><a href="http://www.imd.gov.in/Welcome%20To%20IMD/Welcome.php">IMD page</a></li>
                </ul>
            </div>

        </div>

        <div class="row">
            <p>
                Copyright &copy; 2019 by India Meteorological Department. All rights reserved.
            </p>
        </div>
    </footer>


    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>


    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/script.js"></script>

    
  <!--  <script type="text/javascript">
    window._chatlio = window._chatlio||[];
    !function(){ var t=document.getElementById("chatlio-widget-embed");if(t&&window.ChatlioReact&&_chatlio.init)return void _chatlio.init(t,ChatlioReact);for(var e=function(t){return function(){_chatlio.push([t].concat(arguments)) }},i=["configure","identify","track","show","hide","isShown","isOnline", "page", "open", "showOrHide"],a=0;a<i.length;a++)_chatlio[i[a]]||(_chatlio[i[a]]=e(i[a]));var n=document.createElement("script"),c=document.getElementsByTagName("script")[0];n.id="chatlio-widget-embed",n.src="https://w.chatlio.com/w.chatlio-widget.js",n.async=!0,n.setAttribute("data-embed-version","2.3");
       n.setAttribute('data-widget-id','50e35412-6e46-4385-4a6d-781ee8ca1f76');
       c.parentNode.insertBefore(n,c);
    }();
</script>
    -->
    
  <script src="https://lex-web-ui-codebuilddeploy-1aelowji3-webappbucket-1xa5ccwjk82vc.s3.amazonaws.com/lex-web-ui-loader.min.js"></script>
<script>
  var loaderOpts = {
    baseUrl: 'https://lex-web-ui-codebuilddeploy-1aelowji3-webappbucket-1xa5ccwjk82vc.s3.amazonaws.com/'
  };
  var loader = new ChatBotUiLoader.IframeLoader(loaderOpts);
  loader.load()
    .catch(function (error) { console.error(error); });
</script>

</body>

</html>
