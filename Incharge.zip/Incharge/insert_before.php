<?php
$con = mysqli_connect("173.194.107.32","NikhilOke","1234","imd_db");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
else 
    
/*$result = filter_input_array(INPUT_POST);*/
if( isset($_POST['submit']))
{
    
    $value=$_POST['sel'];
    $aws_id=$_POST['AWS_id'];  
    $region =$_POST['AWS_region'];
    $stn_name=$_POST['AWS_stn_name'];
    $name_so = $_POST['name_so'];
    $cost = $_POST['cost'];
    $exposure = $_POST['exposure'];
    $mast=$_POST['sel_mast'];
    $fence=$_POST['sel_fence'];
    $solar=$_POST['sel_solar'];
    $sensor=$_POST['sel_sensor'];
     $nema=$_POST['sel_nema'];
     $wire=$_POST['sel_wire'];
     $gauge=$_POST['sel_gauge'];
    $battery_volt=$_POST['battery_volt'];
     $charge=$_POST['sel_charge'];
     $grass=$_POST['sel_grass'];
     $painting=$_POST['sel_painting'];
    $date1=$_POST['date1'];
    $deg1=$_POST['deg1'];
    $rh1=$_POST['rh1'];
    $slp1=$_POST['slp1'];
    $ws1=$_POST['ws1'];
    $wd1=$_POST['wd1'];
    $rain1=$_POST['rain1'];
    $rad1=$_POST['rad1'];
    $st1=$_POST['st1'];
    $sm1=$_POST['sm1'];
     $date2=$_POST['date2'];
    $deg2=$_POST['deg2'];
    $rh2=$_POST['rh2'];
    $slp2=$_POST['slp2'];
    $ws2=$_POST['ws2'];
    $wd2=$_POST['wd2'];
    $rain2=$_POST['rain2'];
    $rad2=$_POST['rad2'];
    $st2=$_POST['st2'];
    $sm2=$_POST['sm2'];
     $date3=$_POST['date3'];
    $deg3=$_POST['deg3'];
    $rh3=$_POST['rh3'];
    $slp3=$_POST['slp3'];
    $ws3=$_POST['ws3'];
    $wd3=$_POST['wd3'];
    $rain3=$_POST['rain3'];
    $rad3=$_POST['rad3'];
    $st3=$_POST['st3'];
    $sm3=$_POST['sm3'];
     $adate1=$_POST['adate1'];
    $adeg1=$_POST['adeg1'];
    $arh1=$_POST['arh1'];
    $aslp1=$_POST['aslp1'];
    $aws1=$_POST['aws1'];
    $awd1=$_POST['awd1'];
    $arain1=$_POST['arain1'];
    $arad1=$_POST['arad1'];
    $ast1=$_POST['ast1'];
    $asm1=$_POST['asm1'];
     $adate2=$_POST['adate2'];
    $adeg2=$_POST['adeg2'];
    $arh2=$_POST['arh2'];
    $aslp2=$_POST['aslp2'];
    $aws2=$_POST['aws2'];
    $awd2=$_POST['awd2'];
    $arain2=$_POST['arain2'];
    $arad2=$_POST['arad2'];
    $ast2=$_POST['ast2'];
    $asm2=$_POST['asm2'];
     $adate3=$_POST['adate3'];
    $adeg3=$_POST['adeg3'];
    $arh3=$_POST['arh3'];
    $aslp3=$_POST['aslp3'];
    $aws3=$_POST['aws3'];
    $awd3=$_POST['awd3'];
    $arain3=$_POST['arain3'];
    $arad3=$_POST['arad3'];
    $ast3=$_POST['ast3'];
    $asm3=$_POST['asm3'];
    $action_battery=$_POST['bat'];
    $action_rainfall=$_POST['rainfall'];
    $action_met=$_POST['met'];
    $action_site=$_POST['site_cleaned'];
    $action_solar=$_POST['solar_panel'];
    $action_painting=$_POST['painting_done'];
    $action_physical=$_POST['physical'];
    $action_tx=$_POST['tx'];
    $action_rain=$_POST['rain_gauge'];
    $action_gps=$_POST['gps'];
    $remark_battery=$_POST['remark_battery'];
    $remark_rainfall=$_POST['remark_rainfall'];
    $remark_met=$_POST['remark_met'];
    $remark_site=$_POST['remark_site'];
    $remark_solar=$_POST['remark_solar'];
    $remark_painting=$_POST['remark_paint'];
    $remark_physical=$_POST['remark_physical'];
    $remark_tx=$_POST['remark_tx'];
    $remark_rain=$_POST['remark_raingauge'];
    $remark_gps=$_POST['remark_gps'];
    $remark_confirm = $_POST['remark_confirm'];
    $confirm_status = $_POST['confirm_status'];
}

    

$report_status='not verified';
$sql = "insert into Report values(Null,$aws_id,'$stn_name','$region','$report_status','$name_so',$cost ,'$value',curdate(),'$exposure','$mast','$fence','$solar','$sensor','$nema','$wire','$gauge',' $battery_volt','$charge','$grass','$painting','$date1','$deg1','$rh1','$slp1','$ws1','$wd1','$rain1','$rad1','$st1','$sm1','$adate1','$adeg1',' $arh1','$aslp1','$aws1','$awd1','$arain1','$arad1','$ast1','$asm1',' $action_battery',' $action_rainfall','$action_met','$action_site','$action_solar','$action_painting','$action_physical','$action_tx','$action_rain','$action_gps','$remark_battery','$remark_rainfall',' $remark_met',' $remark_site','$remark_solar','$remark_painting','$remark_physical',' $remark_tx','$remark_rain','$remark_gps','$remark_confirm',' $confirm_status');";

if(mysqli_query($con,$sql))
{
    echo 'inserted';
}
else
    echo ' failure ';