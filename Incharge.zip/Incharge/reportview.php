<!DOCTYPE html>
<html>

<head>

    <meta name="viewport" content="width=devices-width,initial-scale=1.0">


    <title>Report view</title>
    <!--   
         
-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt" crossorigin="anonymous">

    <link rel="stylesheet" href="css/loginstyle.css">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

    <style>
        .center {
            height: 120px;
            margin-right: auto;
            margin-left: auto;
        }

    </style>

</head>

<body>

    <?php
    $id = $_GET["id"];
  
$con = mysqli_connect("173.194.107.32","NikhilOke","1234","imd_db");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
else 
    echo " connection succesful ";

$sql = "SELECT * FROM Report WHERE report_id =".$id;
$result = mysqli_query($con, $sql); 
$res = mysqli_fetch_array($result);
    
 
    
    
//echo $res['report_id'];
            
   /* $report_id = $row["report_id"];
    $stb_id = $row["stn_id"];
    $stn_name = $row["stn_name"];
    $region = $row["region"];
    $status = $row["status"];
    $name_so = $row["name_so"];
    $cost = $row["cost"];
    $status_before = $row["status_before"];
    $date = $row["date"];
    */
    
    
    ?>

    <nav class="navbar fixed-top navbar-expand-sm navbar-light bg-light ">

        <div class="container">

            <a class="navbar-brand" href="index.html"><img src="netsource/image/IMD_logo.jpg" style="height: 50px; width: auto;"></a>

            <ul class="navbar-nav ">
                <li class="nav-item">
                    <a class="nav-link" href="admin/admin.php">Back</a>


            </ul>




        </div>

    </nav>

    <!-- FLUID JUMBOTRON -->
    <div class="jumbotron jumbotron-fluid" style="padding-top: 150px;">
        <div class="container">
            <center>
                <img src="netsource/image/IMD_logo.jpg" class="center">
                <h1 class="display-4">India Meteorological Department</h1>
            </center>
            <hr>

            <center>
                <h3 class="sticky-top" style="padding-top: 70px;">AWS Maintenance Report</h3>
            </center>

            <blockquote class="blockquote" style="padding-top: 30px;">

                <label>Report No. : </label><?php echo " ". $res['report_id']; ?><br>
                <label>Station ID : </label><?php  echo " ". $res['stn_id']; ?> <label class="float-right">Date :  <?php  echo " ". $res['date'];  ?></label><br>
                <label>Station Name : </label><?php  echo " ". $res['stn_name'];  ?> <br>
                <label>Region : </label><?php  echo " ". $res['region'];  ?> <br>

                <label>Status : </label><?php  echo " ". $res['status'];  ?> <br>
                <label>Name of servicing officer : </label><?php  echo " ". $res['name_so'];  ?> <br>
                <label>Cost of maintenance : </label><?php  echo " ". $res['cost'];  ?> <br>

                <label>AWS status before maintenance : </label><?php  echo " ". $res['status_before'];  ?> <br>



                <hr style="color: black;">

                <h4 style="padding-top: 30px;">Physical Conditions</h4>

                <label style="padding-top: 20px;">Exposure Conditions at site : </label><?php  echo " ". $res['exposure'];  ?> <br>

                <label>Mast : </label><?php  echo " ". $res['mast'];  ?> <br>

                <label>Fencing : </label><?php  echo " ". $res['fencing'];  ?> <br>
                <label>Solar Panel : </label><?php  echo " ". $res['solar panel'];  ?> <br>
                <label>Sensors : </label><?php  echo " ". $res['sensor'];  ?> <br>
                <label>Nema Enclosure : </label><?php  echo " ". $res['nema enclosure'];  ?> <br>
                <label>Guy wire : </label><?php  echo " ". $res['guy wire'];  ?> <br>
                <label>Rain gauges : </label><?php  echo " ". $res['rain gauge'];  ?> <br>
                <label>Battery voltage : </label><?php  echo " ". $res['battery_volt'];  ?> <br>
                <label>Solar charging : </label><?php  echo " ". $res['solar charging'];  ?> <br>
                <label>Grass cutting : </label><?php  echo " ". $res['grass cutting'];  ?> <br>
                <label>Painting of Mast : </label><?php  echo " ". $res['painting of mast'];  ?> <br>
                <label>Image before Maintainence : </label><?php  echo " ". $res['img before'];  ?> <br>
                <label>Image After Maintainence : </label><?php  echo " ". $res['img after'];  ?> <br>
                <hr>

                <!-- DataTales Example -->
                <div class="card shadow mb-4" style=" margin-top: 50px;">
                    <div class="card-header py-3">
                        <h4 class="m-0 <!--font-weight-bold --> ">Before Maintenance</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>AT Deg</th>
                                        <th>RH%</th>
                                        <th>SLP hpa</th>
                                        <th>WS</th>
                                        <th>WD Deg</th>
                                        <th>Rain mm</th>
                                        <th>RAD</th>
                                        <th>ST</th>
                                        <th>SM</th>

                                    </tr>
                                </thead>

                                <tbody>
                                    <tr>

                                        <td><?php  echo " ". $res['b_Date'];  ?></td>
                                        <td><?php  echo " ". $res['at_deg'];  ?></td>
                                        <td><?php  echo " ". $res['rh'];  ?></td>
                                        <td><?php  echo " ". $res['SLP_hpa'];  ?></td>
                                        <td><?php  echo " ". $res['WS'];  ?></td>
                                        <td><?php  echo " ". $res['WD'];  ?></td>
                                        
                                        <td><?php  echo " ". $res['Rain_mm'];  ?></td>
                                        <td><?php  echo " ". $res['rad'];  ?></td>
                                        <td><?php  echo " ". $res['ST'];  ?></td>
                                        <td><?php  echo " ". $res['Sm'];  ?></td>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- DataTales Example -->
                <div class="card shadow mb-4" style=" margin-top: 50px;">
                    <div class="card-header py-3">
                        <h4 class="m-0 <!--font-weight-bold --> ">After Maintenance</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>AT Deg</th>
                                        <th>RH%</th>
                                        <th>SLP hpa</th>
                                        <th>WS</th>
                                        <th>WD Deg</th>
                                        <th>Rain mm</th>
                                        <th>RAD</th>
                                        <th>ST</th>
                                        <th>SM</th>

                                    </tr>
                                </thead>

                                <tbody>
                                    <tr>

                                        <td><?php  echo " ". $res['a_Date'];  ?></td>
                                        <td><?php  echo " ". $res['a_at_deg'];  ?></td>
                                        <td><?php  echo " ". $res['a_rh'];  ?></td>
                                        <td><?php  echo " ". $res['a_SLP_hpa'];  ?></td>
                                        <td><?php  echo " ". $res['a_WS'];  ?></td>
                                        <td><?php  echo " ". $res['a_WD'];  ?></td>
                                        
                                        <td><?php  echo " ". $res['a_Rain_mm'];  ?></td>
                                        <td><?php  echo " ". $res['a_rad'];  ?></td>
                                        <td><?php  echo " ". $res['a_ST'];  ?></td>
                                        <td><?php  echo " ". $res['a_Sm'];  ?></td>


                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <hr>
                <h4 style="padding-top: 50px;">Action Report During visit</h4>



                <div class="table-responsive">
                    <table class="table">

                        <thead>
                            <tr>
                                <th>Sn no</th>
                                <th>Details</th>
                                <th>Result</th>
                                <th>Remarks</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>Battery is being charged</td>
                                <td><?php  echo " ". $res['battery'];  ?> </td>
                                <td><input type=text style="width: 250px" value="<?php  echo " ". $res['remark_battery'];  ?>" disabled/></td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>Rainfall sensor cleaned</td>
                                <td><?php  echo " ". $res['rainfall_sensor'];  ?> </td>
                                <td><input type=text style="width: 250px" value= "<?php  echo " ". $res['remark_rainfall_sensor'];  ?>" disabled/></td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td>All met parameters data of AWS site are of good quality</td>
                                <td><?php  echo " ". $res['met_para'];  ?> </td>
                                <td><input type=text style="width: 250px" value="<?php  echo " ". $res['remark_met_para'];  ?>" disabled/></td>
                            </tr>
                            <tr>
                                <td>4</td>
                                <td>Site cleaned</td>
                                <td><?php  echo " ". $res['site_cleaned'];  ?> </td>
                                <td><input type=text style="width: 250px" value="<?php  echo " ". $res['remark_site_cleaned'];  ?>" disabled/></td>
                            </tr>
                            <tr>
                                <td>5</td>
                                <td>Solar panel cleaned</td>
                                <td><?php  echo " ". $res['solar_cleaned'];  ?> </td>
                                <td><input type=text style="width: 250px" value="<?php  echo " ". $res['remark_solar_cleaned'];  ?>" disabled /></td>
                            </tr>
                            <tr>
                                <td>6</td>
                                <td>Painting Done</td>
                                <td><?php  echo " ". $res['painting'];  ?> </td>
                                <td><input disabled  type=text style="width: 250px" value= "<?php  echo " ". $res['remark_painting'];  ?>" /></td>
                            </tr>
                            <tr>
                                <td>7</td>
                                <td>All physical details of AWS are correct</td>
                                <td><?php  echo " ". $res['phy_data'];  ?> </td>
                                <td><input disabled  type=text style="width: 250px" value="<?php  echo " ". $res['remark_phy_data'];  ?>" /></td>
                            </tr>
                            <tr>
                                <td>8</td>
                                <td>Check Transmission Power with R/f power meter</td>
                                <td><?php  echo " ". $res['tx_rf'];  ?> </td>
                                <td><input disabled type=text style="width: 250px" value="<?php  echo " ". $res['remark_tx_rf'];  ?>" /></td>
                            </tr>
                            <tr>
                                <td>9</td>
                                <td>Caliberation of Rain Gauge</td>
                                <td><?php  echo " ". $res['rain_gauge'];  ?> </td>
                                <td><input disabled type=text style="width: 250px" value="<?php  echo " ". $res['remark_rain_gauge'];  ?>" /></td>
                            </tr>
                            <tr>
                                <td>10</td>
                                <td>Check GPS status with Earth station AWS Pune</td>
                                <td><?php  echo " ". $res['gps'];  ?> </td>
                                <td><input disabled type=text style="width: 250px"; value="<?php  echo " ". $res['remark_gps'];  ?>" /></td>
                            </tr>


                        </tbody>
                    </table>

                </div>


                <div style="padding: 30px;">
                    <label> Any Remarks :
                    </label><?php echo " ". $res['incharge_remarks']; ?><br><br>
                    <label> Present status :
                    </label><?php echo " ". $res['incharge_status']; ?><br><br>

   <?php 
                    ?>                 

                    <!-- TEXTAREA -->
                    <div class="form-group">
                        <label for="Administrator Remark : ">Administrator Remark : </label>
                        <textarea class="form-control" id="message" rows="3"></textarea>
                    </div>

                </div>

                <center>
                    <div>
                        <button class="btn btn-outline-danger" type="button" style="margin:10px;">Reject</button>
                        <button class="btn btn-outline-success" type="button" style="margin:10px;">Verified</button>

                    </div>
                </center>



            </blockquote>








        </div>
    </div>




    <!-- php end  -->

    <hr>
    <!-- Footer -->
    <footer class="sticky-footer bg-white">
        <div class="container my-auto">
            <div class="copyright text-center my-auto">
                <span>Copyright &copy; India Meteorological Department 2019</span>
            </div>
        </div>
    </footer>
    <!-- End of Footer -->








    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="js/bootstrap-show-password.min.js"></script>

    
    
</body>

</html>
