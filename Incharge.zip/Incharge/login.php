
<!DOCTYPE html>
<html>

<head>

    <meta name="viewport" content="width=devices-width,initial-scale=1.0">


    <title>Login</title>
    <!--   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
         
--><!-- Javascript SDKs-->
	<script src="https://code.jquery.com/jquery-1.11.3.min.js"></script> 
	<script src="js/amazon-cognito-auth.min.js"></script>
	<script src="https://sdk.amazonaws.com/js/aws-sdk-2.7.16.min.js"></script> 
	<script src="js/amazon-cognito-identity.min.js"></script>   
	<script src="js/config.js"></script>
    
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt" crossorigin="anonymous">

    <link rel="stylesheet" href="css/loginstyle.css">
    
    
    

</head>

<body>


    <nav class="navbar fixed-top navbar-expand-sm navbar-light bg-light ">

        <div class="container">

            <a class="navbar-brand" href="index.html"><img src="netsource/image/IMD_logo.jpg" style="height: 50px; width: auto;"></a>

            <ul class="navbar-nav ">
                <li class="nav-item">
                    <a class="nav-link" href="index.html">Home</a>
                </li>

                <li class="nav-item">
                    <a href="index.html#About" class="nav-link">About us</a>
                </li>
                <li class="nav-item">
                    <a href="index.html#Maintenanceinfo" class="nav-link">Maintenance Info</a>
                </li>
                <li class="nav-item">
                    <a href="index.html#contact" class="nav-link">Contact us</a>
                </li>

            </ul>




        </div>

    </nav>

    <div class="container login-container">
        <div class="row" style="padding: 22px;">
            <div class="col-md-6 login-form-1">
                <h3>Administrator</h3>
                <form action="login_user.php" method="post">
                    <div class="form-group">
                        <input type="text" class="form-control" id="inputUsername"  placeholder="Your Email *" name="username"  value="" />
                    </div>
                    <div class="form-group input-group">
                        <input type="password" class="form-control" id="inputPassword" placeholder="Your Password *" value="" name="password" data-toggle="password" />
                        <div class="input-group-append">
                            <span class="input-group-text">
                                <i class="fa fa-eye"></i>
                            </span>
                        </div>

                    </div>
                    <div class="form-group">
                       <!-- <input type="submit" class="btnSubmit" value="Login" onclick="signInButton()" /> -->
                        <input type="submit" onclick="signInButton()" class="btnSubmit"  value="Login" name="login">
                    </div>
                    <div class="form-group">
                        <a href="#" class="ForgetPwd"  onclick="forgotpasswordbutton()" >Forget Password?</a>
                       

                    </div>
                </form>
            </div>
            <div class="col-md-6 login-form-2">
                <h3>Station Incharge</h3>
                <form action="login_incharge.php" method="post">
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Your Email *" value="" name="incharge_id" />
                    </div>
                    <div class="form-group input-group">
                        <input type="password" class="form-control" placeholder="Your Password *" value="" data-toggle="password"  name="incharge_pass"/>
                        <div class="input-group-append">
                            <span class="input-group-text">
                                <i class="fa fa-eye"></i>
                            </span>
                        </div>
                    </div>
                    <div class="form-group">
                        <input type="submit" class="btnSubmit" value="Login" />
                    </div>
                    <div class="form-group">

                        <a href="#" class="ForgetPwd" value="Login">Forget Password?</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <hr>
    <!-- Footer -->
    <footer class="sticky-footer bg-white">
        <div class="container my-auto">
            <div class="copyright text-center my-auto">
                <span>Copyright &copy; India Meteorological Department 2019</span>
            </div>
        </div>
    </footer>
    <!-- End of Footer -->









    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="js/bootstrap-show-password.min.js"></script>
    
    
    
    <script>

  function signInButton() {
    
	var authenticationData = {
        Username : document.getElementById("inputUsername").value,
        Password : document.getElementById("inputPassword").value,
    };
	
    var authenticationDetails = new AmazonCognitoIdentity.AuthenticationDetails(authenticationData);
    
	var poolData = {
        UserPoolId : _config.cognito.userPoolId, // Your user pool id here
        ClientId : _config.cognito.clientId, // Your client id here
    };
	
    var userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);
	
    var userData = {
        Username : document.getElementById("inputUsername").value,
        Pool : userPool,
    };
	
    var cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
    
	cognitoUser.authenticateUser(authenticationDetails, {
        onSuccess: function (result) {
			var accessToken = result.getAccessToken().getJwtToken();
			console.log(accessToken);	
        },

        onFailure: function(err) {
            alert(err.message || JSON.stringify(err));
        },
    });
  }
        
        
    function forgotpasswordbutton() {
	var poolData = {
        UserPoolId : _config.cognito.userPoolId, // Your user pool id here
        ClientId : _config.cognito.clientId, // Your client id here
    };
	
    var userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);
	
    var userData = {
        Username : document.getElementById("inputUsername").value,
        Pool : userPool,
    };
	
    var cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
		
    cognitoUser.forgotPassword({
        onSuccess: function (result) {
            console.log('call result: ' + result);
        },
        onFailure: function(err) {
            alert(err);
			console.log(err);
        },
        inputVerificationCode() {
            var verificationCode = prompt('Please input verification code ' ,'');
            var newPassword = prompt('Enter new password ' ,'');
            cognitoUser.confirmPassword(verificationCode, newPassword, this);
        }
    });
  }
        
        
</script>
    

</body>

</html>
