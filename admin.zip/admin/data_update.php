<?php
$con = mysqli_connect("173.194.107.32","NikhilOke","1234","imd_db");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$id=$_POST['hidden_id'];
echo $id ;
$sql="UPDATE Report SET status = 'Verified' where report_id=$id; ";
if(mysqli_query($con,$sql))
{
    header("location:admin.php");
}
else
echo 'fail';
?>