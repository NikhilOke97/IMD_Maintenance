<!DOCTYPE html>
<html lang="en">
<?php 
    session_start();
        ?>
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin Personal</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">




</head>
<?php 
            $con = mysqli_connect("173.194.107.32","NikhilOke","1234","imd_db");
            $sql = "SELECT * FROM Administrator WHERE ID ='".$_SESSION['user_admin']."'";
            $result = mysqli_query($con,$sql); 
           $res = mysqli_fetch_array($result);
?>


<body id="page-top">

    <div class="container">

        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">Settings</h1>
        <p class="mb-4">The Page contains settings regarding the employee account. </p>

        <hr>

        <blockquote class="blockquote" style="padding-top: 30px;">

            <label>Employee ID : <?php echo $res['ID'] ?></label> <br>
            <label>Name :  <?php echo $res['Name'] ?></label><br>
            <label>Email : <?php echo $res['Email'] ?></label><br>

            <hr>

            <!-- BUTTON WITH COLLAPSE -->
            <button class="btn btn-primary d-block mb-4" data-toggle="collapse" data-target="#collapse-btn-1">Change Password</button>

            <div class="collapse mb-5" id="collapse-btn-1">
                <div class="card">
                    <div class="card-body">

                        <div class="form-group">
                            <label for="email">Email address</label>
                            <input class="form-control form-control-lg" type="email" id="email" placeholder="Enter email">
                            <small class="form-text text-muted">Your email will not ever be shared</small>
                        </div>

                        <div class="form-group">
                            <label for="password">Old Password</label>
                            <input class="form-control" type="password" id="password" placeholder="Password">
                        </div>
                        <div class="form-group">
                            <label for="password">New Password</label>
                            <input class="form-control" type="password" id="password" placeholder="Password">
                        </div>

                        <div class="form-group">
                            <label for="password">Confirm New Password</label>
                            <input class="form-control" type="password" id="password" placeholder="Password">
                        </div>

                        <center>
                            <button class="btn btn-info d-block mb-4">Submit</button>
                        </center>

                    </div>
                </div>
            </div>




        </blockquote>

    </div>








    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>
    <script src="https://code.jquery.com/jquery-1.10.2.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>



</body></html>
    
    
    
    