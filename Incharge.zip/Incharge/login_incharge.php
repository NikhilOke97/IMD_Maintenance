<?php
session_start();
$con = mysqli_connect("173.194.107.32","NikhilOke","1234","imd_db");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


$email=$_POST['incharge_id'];
$_SESSION['user_incharge']=$email;
$pass=$_POST['incharge_pass'];
$sql_query="select password from station_officer where Name='$email';";
$query_result= mysqli_query($con,$sql_query);
$res = mysqli_fetch_array($query_result);

if($pass===$res['password'])
{
    header("location:admin/demo1.php");
   
}
else
{
   
    ?>
    <html>
        <head>
            <script>
             function myfun()
             {
                 var r = confirm("Invalid Incharge!!");
                 if(r === true)
                 {
                    goBack();
                 }
             }
             
             function goBack()
             {
                 window.history.go(-1);
             }
             </script>
        </head>
        <body onload="myfun()">
             
        </body>
    </html>
    <?php
    
}

?>