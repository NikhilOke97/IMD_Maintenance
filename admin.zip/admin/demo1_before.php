<?php 
session_start();
$incharge=$_SESSION['user_incharge'];
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <!-- <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>-->

     <!--Cognito JavaScript-->
	<script src="../js/amazon-cognito-identity.min.js"></script>  
	<script src="../js/config.js"></script>
    <script src="../js/config.js"></script>


</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="demo1.php">
                <!--    <div class="sidebar-brand-icon rotate-n-15">
         <i class="fas fa-laugh-wink"></i>  
        </div> -->
                <div class="sidebar-brand-text mx-3"> station incharge </div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="#">
                    <i class="far fa-file"></i>
                    <span>New Record</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading REPORT -->
            <div class="sidebar-heading">
                REPORT
            </div>

            <!-- Nav Item - Pages Collapse Menu - maintenance report -->
             <li class="nav-item">
                <a class="nav-link"  href="#" id="maintenance">
                    <i class="fas fa-table"></i>
                    <span>Maintenance Record</span></a>
            </li>

             <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading Account -->
            <div class="sidebar-heading">
                incharge ACCOUNT
            </div>

            <li class="nav-item">
                <a class="nav-link" href="#" id="personal">
                    <i class="far fa-user-circle"></i>
                    <span>Personal</span></a>

            </li>

           <!-- <li class="nav-item">
                <a class="nav-link"  href="#" id="setting">
                    <i class="fas fa-table"></i>
                    <span>Settings</span></a>
            </li> -->

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">


                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Search -->
                    <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
                        <div class="input-group">
                            <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="button">
                                    <i class="fas fa-search fa-sm"></i>
                                </button>
                            </div>
                        </div>
                    </form>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                                <form class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="button">
                                                <i class="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>


                        <!-- Nav Item - Alerts -->
                        <li class="nav-item dropdown no-arrow mx-1">
                            <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-bell fa-fw"></i>
                                <!-- Counter - Alerts -->
                                <span class="badge badge-danger badge-counter">1+</span>
                            </a>
                            <!-- Dropdown - Alerts -->
                            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="alertsDropdown">
                                <h6 class="dropdown-header">
                                    Alerts Center
                                </h6>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-primary">
                                            <i class="fas fa-file-alt text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">December 12, 2019</div>
                                        <span class="font-weight-bold">A new monthly report is ready to download!</span>
                                    </div>
                                </a>

                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-warning">
                                            <i class="fas fa-exclamation-triangle text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">December 2, 2019</div>
                                        Spending Alert: We've noticed unusually high spending for your account.
                                    </div>
                                </a>
                                <a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
                            </div>
                        </li>

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><label id="name_value"></label></span>
                                <img class="img-profile rounded-circle" src="img/New%20Doc%202018-06-09_1%20(1).jpg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                                <a class="dropdown-item" id="profile" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                <a class="dropdown-item" id="setting1" href="#">
                                    <i class="fas fa-cog fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Settings
                                </a>
                              <!--  <a class="dropdown-item" href="#">
                                    <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Activity Log
                                </a> -->
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item"  href="../login.html" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>


                    </ul> <!-- End of right section Topbar -->


                </nav>
                <!-- End of Topbar -->


                <!-- Begin Page Content -->
                <div class="container-fluid" id="mc">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">New Record</h1>

                    </div>


                    <!-- Content Row -->
                    <div class="row">
                        
                        <div id = "new_maintainance_record" class="tab-content">
<ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#Basic">Basic  </a></li>
    <li style="padding-left: 15px"><a data-toggle="tab" href="#Detailed"> |  Detailed</a></li>
    <li style="padding-left: 15px"><a data-toggle="tab" href="#Confirm">|   Confirmation</a></li>
  </ul>
<form  method="post" action="insert.php">
<div class="tab-content">
     <div id="Basic" class="tab-pane fade in active">
                        <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="well well-sm">
                                    <legend style="padding-top: 20px">Maintenance Report</legend>
                                      <!-- <form  method="POST" action="insert.php">-->
                                              <div class="form-group col-md-8">
                                            <input name="AWS_region" type="text" placeholder="AWS region name" class="form-control">
                                           </div>
                                      
                                           <div class=" form-group  col-md-8">
                                               <input name="AWS_id" type="numeric" placeholder="AWS id" class="form-control">
                                           </div>
                                     
                                            <div class=" form-group  col-md-8">
                                               <input name="AWS_stn_name" type="numeric" placeholder="Station Name" class="form-control">
                                           </div>      
                                            <div class=" form-group  col-md-8">
                                               <input name="name_so" type="numeric" placeholder="Name of servicing officer" class="form-control">
                                           </div>      
                                            <div class="form-inline">
                                    Cost of Maintenance 
                                    <div class="col-md-3">
                                        <input name="cost" type="text   " placeholder="Cost of Maintenance" class="form-control">
                                    </div>
                                    </div><br>
                                         
                                      <label style="padding-right: 25px">AWS status before maintenance</label>
                                       <select name="sel">
                                           <option value="Working">Working</option>
                                            <option value="Not Working">Not working</option>
                                        </select>
                                    
                                    <div class="form-inline">
                                    Exposure Conditions at site 
                                    <div class="col-md-3">
                                        <input name="exposure" type="text" placeholder="Exposure conditions" class="form-control">
                                    </div>
                                    </div><br>
                                    <h4>Physical Conditions</h4>
                        <div class=" form-inline">
                              <span class="labelclass">Mast :</span>  
                            <select class="form-control" name="sel_mast">
                                        <option value="Ok">Ok</option>
                                        <option value="Not OK">Not OK</option>
        
                                </select>
                            </div><br>
                       <div class="form-inline">
                            Fencing
                                <select class="form-control" name="sel_fence">
                                      <option value="Ok">Ok</option>
                                        <option value="Not OK">Not OK</option>
        
                                </select>
                            </div><br>
                         <div class="form-inline">
                            Solar Panel
                                <select class="form-control" name="sel_solar">
                                        <option value="Ok">Ok</option>
                                        <option value="Not OK">Not OK</option>
                                </select>
                            </div><br>
                         <div class="form-inline">
                            Sensors
                                <select class="form-control" name="sel_sensor">
                                        <option value="Ok">Ok</option>
                                        <option value="Not OK">Not OK</option>
        
                                </select>
                            </div><br>
                         <div class="form-inline">
                            Nema Enclosure
                                <select class="form-control" name="sel_nema">
                                        <option value="Ok">Ok</option>
                                        <option value="Not OK">Not OK</option>
        
                                </select>
                            </div><br>
                         <div class="form-inline">
                            Guy wire
                                <select class="form-control" name="sel_wire">
                                        <option value="Ok">Ok</option>
                                        <option value="Not OK">Not OK</option>
        
                                </select>
                            </div><br>
                     <div class="form-inline">
                            Rain gauges 
                                <select class="form-control" name="sel_gauge">
                                        <option value="Ok">Ok</option>
                                        <option value="Not OK">Not OK</option>
                                </select>
                            </div><br>
                        <div class="form-inline">
                            Battery voltage 
                                <input  name="battery_volt" type="number" placeholder="battery voltage">
                            </div><br>
                    <div class="form-inline">
                            Solar charging  :
                                <select class="form-control" name="sel_charge">
                                       <option value="Ok">Ok</option>
                                        <option value="Not OK">Not OK</option>
        
                                </select>
                            </div><br>
                    <div class="form-inline">
                            Grass cutting  :
                                <select class="form-control" name="sel_grass">
                                        <option value="Done">Done</option>
                                        <option value="Not Done">Not Done</option>
        
                                </select>
                            </div><br>
                        <div class="form-inline">
                            Painting of Mast :
                                <select class="form-control" name="sel_painting">
                                         <option value="Done">Done</option>
                                        <option value="Not Done">Not Done</option>
        
                                </select>
                            </div><br>
                        <div class="form-inline">
                            Image before Maintainence :
                            <input type="file" id="fileToUpload" >
                                
                            </div>
                                    <br>
                      <div class="form-inline">
                            Image After Maintainence :
                            <input type="file" name="img_aft">
                                
                     </div>
                        
                                           
                                </div>
                            </div>
                        </div>
                    </div>
    </div>

<div id="Detailed" class="tab-pane fade"> 
 <h3 style="padding-top: 30px;padding-left:15px;">Before Maintenance</h3>          
  <div class="table-responsive">          
  <table class="table">
      
    <thead>
      <tr>
        <th>Date</th>
        <th>AT Deg</th>
        <th>RH%</th>
        <th>SLP hpa</th>
        <th>WS</th>
        <th>WD Deg</th>
        <th>Rain mm</th>
        <th>RAD</th>  
        <th>ST</th>
        <th>SM</th>
      </tr>
    </thead>
    <tbody>
      <tr>
          <td><input type=text style="width: 50px" name="date1"></td>
          <td><input type=text style="width: 50px" name="deg1"></td>
          <td><input type=text style="width: 50px" name="rh1"></td>
          <td><input type=text style="width: 50px"name="slp1"></td>
          <td><input type=text style="width: 50px" name="ws1"></td>
          <td><input type=text style="width: 50px" name="wd1"></td>
          <td><input type=text style="width: 50px"name="rain1"></td>
          <td><input type=text style="width: 50px" name="rad1"></td>
          <td><input type=text style="width: 50px" name="st1"></td>
          <td><input type=text style="width: 50px" name="sm1"></td>   
      </tr>
          <tr>
        <td><input type=text style="width: 50px" name="date2"></td>
          <td><input type=text style="width: 50px" name="deg2"></td>
          <td><input type=text style="width: 50px" name="rh2"></td>
          <td><input type=text style="width: 50px"name="slp2"></td>
          <td><input type=text style="width: 50px" name="ws2"></td>
          <td><input type=text style="width: 50px" name="wd2"></td>
          <td><input type=text style="width: 50px"name="rain2"></td>
          <td><input type=text style="width: 50px" name="rad2"></td>
          <td><input type=text style="width: 50px" name="st2"></td>
          <td><input type=text style="width: 50px" name="sm2"></td>   
      </tr>
      <tr>
        <td><input type=text style="width: 50px" name="date3"></td>
          <td><input type=text style="width: 50px" name="deg3"></td>
          <td><input type=text style="width: 50px" name="rh3"></td>
          <td><input type=text style="width: 50px"name="slp3"></td>
          <td><input type=text style="width: 50px" name="ws3"></td>
          <td><input type=text style="width: 50px" name="wd3"></td>
          <td><input type=text style="width: 50px"name="rain3"></td>
          <td><input type=text style="width: 50px" name="rad3"></td>
          <td><input type=text style="width: 50px" name="st3"></td>
          <td><input type=text style="width: 50px" name="sm3"></td>   
      </tr>
    
    </tbody>
  </table>
    </div>
<h3 style="padding-top: 80px;padding-left:15px;">After Maintenance</h3>
           
  <div class="table-responsive">          
  <table class="table">
      
    <thead>
      <tr>
        <th>Date</th>
        <th>AT Deg</th>
        <th>RH%</th>
        <th>SLP hpa</th>
        <th>WS</th>
        <th>WD Deg</th>
        <th>Rain mm</th>
        <th>RAD</th>  
        <th>ST</th>
        <th>SM</th>
      </tr>
    </thead>
        <tbody>
      <tr>
          <td><input type=text style="width: 50px" name="adate1"></td>
          <td><input type=text style="width: 50px" name="adeg1"></td>
          <td><input type=text style="width: 50px" name="arh1"></td>
          <td><input type=text style="width: 50px"name="aslp1"></td>
          <td><input type=text style="width: 50px" name="aws1"></td>
          <td><input type=text style="width: 50px" name="awd1"></td>
          <td><input type=text style="width: 50px"name="arain1"></td>
          <td><input type=text style="width: 50px" name="arad1"></td>
          <td><input type=text style="width: 50px" name="ast1"></td>
          <td><input type=text style="width: 50px" name="asm1"></td>   
      </tr>
          <tr>
        <td><input type=text style="width: 50px" name="adate2"></td>
          <td><input type=text style="width: 50px" name="adeg2"></td>
          <td><input type=text style="width: 50px" name="arh2"></td>
          <td><input type=text style="width: 50px"name="aslp2"></td>
          <td><input type=text style="width: 50px" name="aws2"></td>
          <td><input type=text style="width: 50px" name="awd2"></td>
          <td><input type=text style="width: 50px"name="arain2"></td>
          <td><input type=text style="width: 50px" name="arad2"></td>
          <td><input type=text style="width: 50px" name="ast2"></td>
          <td><input type=text style="width: 50px" name="asm2"></td>   
      </tr>
      <tr>
        <td><input type=text style="width: 50px" name="adate3"></td>
          <td><input type=text style="width: 50px" name="adeg3"></td>
          <td><input type=text style="width: 50px" name="arh3"></td>
          <td><input type=text style="width: 50px"name="aslp3"></td>
          <td><input type=text style="width: 50px" name="aws3"></td>
          <td><input type=text style="width: 50px" name="awd3"></td>
          <td><input type=text style="width: 50px"name="arain3"></td>
          <td><input type=text style="width: 50px" name="arad3"></td>
          <td><input type=text style="width: 50px" name="ast3"></td>
          <td><input type=text style="width: 50px" name="asm3"></td>   
      </tr>
    
    </tbody>
  </table>
                
  </div>    
        <h3 style="padding-top: 75px    ">Action Report During visit</h3>
        <!--<div id="Detailed3" >--> 
           
  <div class="table-responsive">          
  <table class="table">
      
    <thead>
      <tr>
        <th>Sn no</th>
        <th>Details</th>
        <th>Result</th>
        <th>Remarks</th>
       </tr>
    </thead>
    <tbody>
      <tr>
        <td>1</td>
          <td>Battery is being charged</td>
          <td> <select class="form-control" name="bat">
                                       <option value="yes">Yes</option>
                                        <option value="no">No</option>
                                </select></td>
          <td><input type=text style="width: 250px" name="remark_battery"></td>
      </tr>
        <tr>
        <td>2</td>
          <td>Rainfall sensor cleaned</td>
          <td> <select class="form-control" name="rainfall">
                                       <option value="yes">Yes</option>
                                        <option value="no">No</option>
        
                                </select></td>
          <td><input type=text style="width: 250px" name="remark_rainfall"></td>
      </tr>
        <tr>
        <td>3</td>
          <td>All met parameters dataof AWS siteare of good quality</td>
          <td> <select class="form-control" name="met">
                                        <option value="yes">Yes</option>
                                        <option value="no">No</option>
        
                                </select></td>
          <td><input type=text style="width: 250px" name="remark_met"></td>
      </tr>
        <tr>
        <td>4</td>
          <td>Site cleaned</td>
          <td> <select class="form-control" name="site_cleaned">
                                      <option value="yes">Yes</option>
                                        <option value="no">No</option>
        
                                </select></td>
          <td><input type=text style="width: 250px" name="remark_site"></td>
      </tr>
        <tr>
        <td>5</td>
          <td>Solar panel cleaned</td>
          <td> <select class="form-control" name="solar_panel">
                                        <option value="yes">Yes</option>
                                        <option value="no">No</option>
        
                                </select></td>
          <td><input type=text style="width: 250px" name="remark_solar"></td>
      </tr>
        <tr>
        <td>6</td>
          <td>Painting Done</td>
          <td> <select class="form-control" name="painting_done">
                                        <option value="yes">Yes</option>
                                        <option value="no">No</option>
        
                                </select></td>
          <td><input type=text style="width: 250px" name="remark_paint"></td>
      </tr>
        <tr>
        <td>7</td>
          <td>All physical details of AWS are correct</td>
          <td> <select class="form-control" name="physical">
                                        <option value="yes">Yes</option>
                                        <option value="no">No</option>
        
                                </select></td>
          <td><input type=text style="width: 250px" name="remark_physical"></td>
      </tr>
        <tr>
        <td>8</td>
          <td>Check Transmission Power with R/f power meter</td>
          <td> <select class="form-control" name="tx">
                                        <option value="yes">Yes</option>
                                        <option value="no">No</option>
                                </select></td>
          <td><input type=text style="width: 250px" name="remark_tx"></td>
      </tr>
        <tr>
        <td>9</td>
          <td>Caliberation of Rain Gauge</td>
          <td> <select class="form-control" name="rain_gauge">
                                       <option value="yes">Yes</option>
                                        <option value="no">No</option>
        
                                </select></td>
          <td><input type=text style="width: 250px" name="remark_raingauge"></td>
      </tr>
        <tr>
        <td>10</td>
          <td>Check GPS status with Earth station AWS Pune</td>
          <td> <select class="form-control" name="gps">
                                        <option value="yes">Yes</option>
                                        <option value="no">No</option>
        
                                </select></td>
          <td><input type=text style="width: 250px" name="remark_gps"></td>
      </tr>
       
    
    </tbody>
  </table>
                
  </div>  
</div>
    <div id="Confirm" class="tab-pane fade">
        <h6 style="padding-top: 30px;padding-left: 10px">Any Remarks</h6>
        <textarea rows="4" cols="50" style="padding-top: 15px" name="remark_confirm"></textarea>
        
        <div class="form-group form-inline" style="padding-top: 20px">
                        Present status  
            <div class="col-md-8">
                                <select class="form-control" name="confirm_status" >
                                        <option value="Working">Working</option>
                                        <option value="Not Working">Not Working</option>
        
                                </select>
                            </div>
            
                            <div class="col-md-12 " style="padding-left: 30px;padding-top: 30px">
                                <button type="submit" class="btn btn-primary btn-lg" name="submit">Submit Report</button>
                            </div>

    </div>
    </div>
    </div>
    </form>
 </div>
 </div>
 </div>
                        
                    </div>


                </div>

                <!-- Content Row -->



                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; India Meteorological Department 2019</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->
            
           
        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" type="button" onclick="signOut()" href="../login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>
    <script src="https://code.jquery.com/jquery-1.10.2.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <script type="text/javascript">
       
       
        
        
        $(document).ready(function() {
            $('#personal').click(function() {
                $('#mc').load('inchargepersonal.php');
            });
        });
        
        $(document).ready(function() {
            $('#setting').click(function() {
                $('#mc').load("settings.html");
            });
        });
        
        $(document).ready(function() {
            $('#maintenance').click(function() {
                $('#mc').load("pastrecord.php");
            });
        });
        
        
        
        $(document).ready(function() {
            $('#stations').click(function() {
                $('#mc').load("stationtables1.php");
            });
        });
        
         $(document).ready(function() {
            $('#rejected').click(function() {
                $('#mc').load("rejectedtable.php");
            });
        });
        
        $(document).ready(function() {
            $('#profile').click(function() {
                $('#mc').load("adminpersonal.html");
            });
        });
        
        $(document).ready(function() {
            $('#setting1').click(function() {
                $('#mc').load("settings.html");
            });
        });
        
        
        
        
        
        
        function signOut(){
	    if (cognitoUser != null) {
          cognitoUser.signOut();	  
        }
	}
        
        
    </script>
    
    <script>
        
         
        var data = {
            UserPoolId: _config.cognito.userPoolId,
            ClientId: _config.cognito.clientId
        };
        var userPool = new AmazonCognitoIdentity.CognitoUserPool(data);
        var cognitoUser = userPool.getCurrentUser();

        window.onload = function() {
            if (cognitoUser != null) {
                cognitoUser.getSession(function(err, session) {
                    if (err) {
                        alert(err);
                        return;
                    }
                    console.log('session validity: ' + session.isValid());
                    //Set the profile info
                    cognitoUser.getUserAttributes(function(err, result) {
                        if (err) {
                            console.log(err);
                            return;
                        }
                        console.log(result);
                        document.getElementById("email_value").innerHTML = result[5].getValue();
                        document.getElementById("phone_value").innerHTML = result[3].getValue();
                        document.getElementById("name_value").innerHTML = result[4].getValue();
                        document.getElementById("id_value").innerHTML = result[4].getValue();

                    });

                });
            }
        }

        
    </script>
    
 
    

</body></html>