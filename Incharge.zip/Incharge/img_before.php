<?php
173.194.107.32","NikhilOke","1234","imd_db");
if(!empty($_GET['id'])){
    //DB details
    $dbHost     = '173.194.107.32';
    $dbUsername = 'NikhilOke';
    $dbPassword = '1234';
    $dbName     = 'imd_db';
    
    //Create connection and select DB
    $db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);
    
    //Check connection
    if($db->connect_error){
       die("Connection failed: " . $db->connect_error);
    }
    
    //Get image data from database
    $result = $db->query("SELECT Before_mntn FROM Report WHERE report_id = {$_GET['id']}");
    
    if($result->num_rows > 0){
        $imgData = $result->fetch_assoc();
        
        //Render image
        header("Content-type: image/jpg"); 
        echo $imgData['image']; 
    }else{
        echo 'Image not found...';
    }
}
?>