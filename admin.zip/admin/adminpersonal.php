<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin Personal</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!--Cognito JavaScript-->
    <script src="../js/amazon-cognito-identity.min.js"></script>
    <script src="../js/config.js"></script>


</head>



<body id="page-top">

    <div class="container">

        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">Personal Data</h1>
        <p class="mb-4">The Page contains all information regarding the employee. </p>

        <hr>

        <blockquote class="blockquote" style="padding-top: 30px;">
      <?php 
            $con = mysqli_connect("173.194.107.32","NikhilOke","1234","imd_db");
            $sql = "SELECT * FROM Administrator WHERE ID ='".$_SESSION['user_admin']."'";
            $result = mysqli_query($con,$sql); 
           $res = mysqli_fetch_array($result);
?>
            <label>Employee ID : <?php echo $res['ID']; ?> </label> <br>
            <label>Name :  <?php echo $res['Name']; ?></label><br>
            <label>Branch :  <?php echo $res['Branch']; ?> </label><br>
            <label>Email :   <?php echo $res['Email']; ?></label><br>
            <label>Employee post : <?php echo $res['Post']; ?></label><br>
            <label>Employee Phone No. : <?php echo $res['Phone_no']; ?></label><br>
            <hr>
            
          <a href="../login.html">  <button type="button" class="btn-primary" onclick="signOut()">Sign out</button></a>
            
        </blockquote>

    </div>








    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>
    <script src="https://code.jquery.com/jquery-1.10.2.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <script>
        var data = {
            UserPoolId: _config.cognito.userPoolId,
            ClientId: _config.cognito.clientId
        };
        var userPool = new AmazonCognitoIdentity.CognitoUserPool(data);
        var cognitoUser = userPool.getCurrentUser();

        window.onload = function() {
            if (cognitoUser != null) {
                cognitoUser.getSession(function(err, session) {
                    if (err) {
                        alert(err);
                        return;
                    }
                    console.log('session validity: ' + session.isValid());
                    //Set the profile info
                    cognitoUser.getUserAttributes(function(err, result) {
                        if (err) {
                            console.log(err);
                            return;
                        }
                        console.log(result);
                        document.getElementById("email_value").innerHTML = result[6].getValue();
                        document.getElementById("phone_value").innerHTML = result[5].getValue();
                        document.getElementById("name_value").innerHTML = result[3].getValue();
                        document.getElementById("id_value").innerHTML = result[4].getValue();

                    });

                });
            }
        }

        function signOut() {
            if (cognitoUser != null) {
                cognitoUser.signOut();
            }
        }
    </script>

</body></html>
    
    
    
    